.. sdaps-class documentation master file, created by
   sphinx-quickstart on Tue Oct 25 19:43:42 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to sdaps-class's documentation!
=======================================

Contents:

Usage Guides
------------
.. toctree::
    :maxdepth: 2

    customlayout

Reference documentation
-----------------------
.. toctree::
    :maxdepth: 2

    sdapsclassic
    sdapslayout
    sdapspdf
    sdapsarray
    sdapsbase


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

