sdaps.annotate package
======================

Submodules
----------

sdaps.annotate.buddies module
-----------------------------

.. automodule:: sdaps.annotate.buddies
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: sdaps.annotate
    :members:
    :undoc-members:
    :show-inheritance:
