sdaps.csvdata package
=====================

Submodules
----------

sdaps.csvdata.buddies module
----------------------------

.. automodule:: sdaps.csvdata.buddies
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: sdaps.csvdata
    :members:
    :undoc-members:
    :show-inheritance:
