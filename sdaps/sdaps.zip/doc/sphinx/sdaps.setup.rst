sdaps.setup package
===================

Submodules
----------

sdaps.setup.additionalparser module
-----------------------------------

.. automodule:: sdaps.setup.additionalparser
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.setupodt.boxesparser module
------------------------------

.. automodule:: sdaps.setupodt.boxesparser
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.setup.buddies module
--------------------------

.. automodule:: sdaps.setup.buddies
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.setupodt.metaparser module
-----------------------------

.. automodule:: sdaps.setupodt.metaparser
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.setupodt.qobjectsparser module
---------------------------------

.. automodule:: sdaps.setupodt.qobjectsparser
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: sdaps.setup
    :members:
    :undoc-members:
    :show-inheritance:
