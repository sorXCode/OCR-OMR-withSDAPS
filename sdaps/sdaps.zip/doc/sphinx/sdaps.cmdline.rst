sdaps.cmdline package
=====================

Submodules
----------

sdaps.cmdline.add module
------------------------

.. automodule:: sdaps.cmdline.add
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.annotate module
-----------------------------

.. automodule:: sdaps.cmdline.annotate
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.boxgallery module
-------------------------------

.. automodule:: sdaps.cmdline.boxgallery
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.convert module
----------------------------

.. automodule:: sdaps.cmdline.convert
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.cover module
--------------------------

.. automodule:: sdaps.cmdline.cover
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.csvdata module
----------------------------

.. automodule:: sdaps.cmdline.csvdata
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.gui module
------------------------

.. automodule:: sdaps.cmdline.gui
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.ids module
------------------------

.. automodule:: sdaps.cmdline.ids
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.info module
-------------------------

.. automodule:: sdaps.cmdline.info
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.recognize module
------------------------------

.. automodule:: sdaps.cmdline.recognize
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.reorder module
----------------------------

.. automodule:: sdaps.cmdline.reorder
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.report module
---------------------------

.. automodule:: sdaps.cmdline.report
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.reporttex module
------------------------------

.. automodule:: sdaps.cmdline.reporttex
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.setup module
--------------------------

.. automodule:: sdaps.cmdline.setup
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.setuptex module
-----------------------------

.. automodule:: sdaps.cmdline.setuptex
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.cmdline.stamp module
--------------------------

.. automodule:: sdaps.cmdline.stamp
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: sdaps.cmdline
    :members:
    :undoc-members:
    :show-inheritance:
