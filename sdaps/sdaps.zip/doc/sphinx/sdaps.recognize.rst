sdaps.recognize package
=======================

Submodules
----------

sdaps.recognize.blank module
----------------------------

.. automodule:: sdaps.recognize.blank
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.recognize.buddies module
------------------------------

.. automodule:: sdaps.recognize.buddies
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.recognize.classic module
------------------------------

.. automodule:: sdaps.recognize.classic
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.recognize.code128 module
------------------------------

.. automodule:: sdaps.recognize.code128
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: sdaps.recognize
    :members:
    :undoc-members:
    :show-inheritance:
