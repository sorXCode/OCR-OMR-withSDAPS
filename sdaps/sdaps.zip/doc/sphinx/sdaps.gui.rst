sdaps.gui package
=================

Submodules
----------

sdaps.gui.buddies module
------------------------

.. automodule:: sdaps.gui.buddies
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.gui.sheet_widget module
-----------------------------

.. automodule:: sdaps.gui.sheet_widget
    :members:
    :undoc-members:
    :show-inheritance:

sdaps.gui.widget_buddies module
-------------------------------

.. automodule:: sdaps.gui.widget_buddies
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: sdaps.gui
    :members:
    :undoc-members:
    :show-inheritance:
