sdaps.setuptex package
======================

Submodules
----------

sdaps.setuptex.sdapsfileparser module
-------------------------------------

.. automodule:: sdaps.setuptex.sdapsfileparser
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: sdaps.setuptex
    :members:
    :undoc-members:
    :show-inheritance:
