#!/bin/sh

sh "run-test.sh" "../sdaps.py"
